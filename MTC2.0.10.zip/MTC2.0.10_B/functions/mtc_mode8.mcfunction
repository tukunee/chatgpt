# 実行
execute as @e[family=mtc_body,tag=mtc_parent,c=1] at @s run scoreboard players set @s mtc_maku 7

execute as @e[family=mtc_body,tag=mtc_parent,c=1] run tag @s add mtc_mode_v2

